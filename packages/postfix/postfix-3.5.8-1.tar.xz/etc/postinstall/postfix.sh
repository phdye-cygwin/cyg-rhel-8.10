if [ ! -f /etc/postfix/access ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/access /etc/postfix/access
fi

if [ ! -f /etc/postfix/aliases ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/aliases /etc/postfix/aliases
fi

if [ ! -f /etc/postfix/canonical ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/canonical /etc/postfix/canonical
fi

if [ ! -f /etc/postfix/generic ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/generic /etc/postfix/generic
fi

if [ ! -f /etc/postfix/header_checks ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/header_checks /etc/postfix/header_checks
fi

if [ ! -f /etc/postfix/main.cf ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/main.cf /etc/postfix/main.cf
fi

if [ ! -f /etc/postfix/main.cf.proto ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/main.cf.proto /etc/postfix/main.cf.proto
fi

if [ ! -f /etc/postfix/master.cf ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/master.cf /etc/postfix/master.cf
fi

if [ ! -f /etc/postfix/master.cf.proto ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/master.cf.proto /etc/postfix/master.cf.proto
fi

if [ ! -f /etc/postfix/postfix-files ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/postfix-files /etc/postfix/postfix-files
fi

if [ ! -f /etc/postfix/relocated ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/relocated /etc/postfix/relocated
fi

if [ ! -f /etc/postfix/transport ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/transport /etc/postfix/transport
fi

if [ ! -f /etc/postfix/virtual ]
then
    /usr/bin/mkdir -p /etc/postfix
    /usr/bin/cp /etc/defaults/etc/postfix/virtual /etc/postfix/virtual
fi

