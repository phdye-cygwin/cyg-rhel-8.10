if [ -f /etc/postfix/access ] && cmp -s /etc/defaults/etc/postfix/access /etc/postfix/access
then
    rm /etc/postfix/access
fi

if [ -f /etc/postfix/aliases ] && cmp -s /etc/defaults/etc/postfix/aliases /etc/postfix/aliases
then
    rm /etc/postfix/aliases
fi

if [ -f /etc/postfix/canonical ] && cmp -s /etc/defaults/etc/postfix/canonical /etc/postfix/canonical
then
    rm /etc/postfix/canonical
fi

if [ -f /etc/postfix/generic ] && cmp -s /etc/defaults/etc/postfix/generic /etc/postfix/generic
then
    rm /etc/postfix/generic
fi

if [ -f /etc/postfix/header_checks ] && cmp -s /etc/defaults/etc/postfix/header_checks /etc/postfix/header_checks
then
    rm /etc/postfix/header_checks
fi

if [ -f /etc/postfix/main.cf ] && cmp -s /etc/defaults/etc/postfix/main.cf /etc/postfix/main.cf
then
    rm /etc/postfix/main.cf
fi

if [ -f /etc/postfix/main.cf.proto ] && cmp -s /etc/defaults/etc/postfix/main.cf.proto /etc/postfix/main.cf.proto
then
    rm /etc/postfix/main.cf.proto
fi

if [ -f /etc/postfix/master.cf ] && cmp -s /etc/defaults/etc/postfix/master.cf /etc/postfix/master.cf
then
    rm /etc/postfix/master.cf
fi

if [ -f /etc/postfix/master.cf.proto ] && cmp -s /etc/defaults/etc/postfix/master.cf.proto /etc/postfix/master.cf.proto
then
    rm /etc/postfix/master.cf.proto
fi

if [ -f /etc/postfix/postfix-files ] && cmp -s /etc/defaults/etc/postfix/postfix-files /etc/postfix/postfix-files
then
    rm /etc/postfix/postfix-files
fi

if [ -f /etc/postfix/relocated ] && cmp -s /etc/defaults/etc/postfix/relocated /etc/postfix/relocated
then
    rm /etc/postfix/relocated
fi

if [ -f /etc/postfix/transport ] && cmp -s /etc/defaults/etc/postfix/transport /etc/postfix/transport
then
    rm /etc/postfix/transport
fi

if [ -f /etc/postfix/virtual ] && cmp -s /etc/defaults/etc/postfix/virtual /etc/postfix/virtual
then
    rm /etc/postfix/virtual
fi

